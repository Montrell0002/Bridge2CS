<?php
$errorMessage = '';
$successMessage = '';
$uploadDir = __DIR__ . '/uploads';
$resumeFilename = 'resume.pdf';
$resumePath = $uploadDir . '/' . $resumeFilename;
$resumeUrl = file_exists($resumePath) ? 'uploads/' . $resumeFilename : null;

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['resume'])) {
    $file = $_FILES['resume'];
    $allowedMime = ['application/pdf'];
    $maxSize = 5 * 1024 * 1024; // 5 MB

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errorMessage = 'Upload failed. Please try again.';
    } elseif (!in_array(mime_content_type($file['tmp_name']), $allowedMime)) {
        $errorMessage = 'Please upload a valid PDF file.';
    } elseif ($file['size'] > $maxSize) {
        $errorMessage = 'Resume must be smaller than 5 MB.';
    } else {
        if (move_uploaded_file($file['tmp_name'], $resumePath)) {
            $successMessage = 'Resume uploaded successfully.';
            $resumeUrl = 'uploads/' . $resumeFilename;
        } else {
            $errorMessage = 'Could not save the file. Check folder permissions.';
        }
    }
}

$githubUrl = 'https://github.com/Montrell0002/Bridge2CS';
$projects = [
    [
        'title' => 'Smart Study Planner',
        'description' => 'An AI-powered study scheduler that adapts deadlines, breaks, and topics to your habits.',
        'tags' => ['PHP', 'JavaScript', 'API', 'Responsive'],
        'link' => '#'
    ],
    [
        'title' => 'Portfolio Dashboard',
        'description' => 'A polished personal dashboard showcasing projects, skills, and live performance metrics.',
        'tags' => ['HTML', 'CSS', 'JS', 'UI/UX'],
        'link' => '#'
    ],
    [
        'title' => 'Code Collaboration Tool',
        'description' => 'A lightweight team workspace for sharing code snippets, tracking tasks, and managing sprints.',
        'tags' => ['PHP', 'MySQL', 'Ajax'],
        'link' => '#'
    ],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio | Computer Science Major</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <div class="brand">
                <span class="brand-accent">CS</span> Portfolio
            </div>
            <nav class="nav-links">
                <a href="#home">Home</a>
                <a href="#resume">Resume</a>
                <a href="#projects">Projects</a>
                <a href="#contact">Contact</a>
                <a class="button button-secondary" href="<?= htmlspecialchars($githubUrl) ?>" target="_blank">GitHub</a>
            </nav>
        </div>
    </header>

    <main>
        <section id="home" class="hero-section">
            <div class="container hero-grid">
                <div class="hero-copy">
                    <span class="eyebrow">Computer Science Major</span>
                    <h1>Building sleek digital experiences with clean code.</h1>
                    <p>Dynamic portfolio with resume upload, elegant project showcase, and GitHub integration. Designed to help you stand out in software engineering and product development.</p>
                    <div class="hero-actions">
                        <a href="#projects" class="button">View Projects</a>
                        <a href="#resume" class="button button-secondary">Upload Resume</a>
                    </div>
                </div>
                <div class="hero-card">
                    <div class="status-chip">Ready for collaboration</div>
                    <div class="hero-card-content">
                        <h2>Skills</h2>
                        <ul>
                            <li>Web Development (HTML, CSS, JavaScript, PHP)</li>
                            <li>Software Architecture & Algorithms</li>
                            <li>Responsive UI/UX Design</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section id="resume" class="section-panel">
            <div class="container section-header">
                <h2>Resume</h2>
                <p>Upload your resume here and preview it instantly on the page.</p>
            </div>
            <div class="container upload-grid">
                <div class="upload-panel">
                    <?php if ($errorMessage): ?>
                        <div class="alert alert-error"><?= htmlspecialchars($errorMessage) ?></div>
                    <?php endif; ?>
                    <?php if ($successMessage): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
                    <?php endif; ?>
                    <form action="#resume" method="post" enctype="multipart/form-data" class="upload-form">
                        <label class="file-input-label" for="resume">Choose a PDF resume</label>
                        <input type="file" name="resume" id="resume" accept="application/pdf" required>
                        <button type="submit" class="button">Upload Resume</button>
                    </form>
                    <?php if ($resumeUrl): ?>
                        <div class="resume-info">
                            <p>Your uploaded resume is ready to view.</p>
                            <a class="button button-secondary" href="<?= htmlspecialchars($resumeUrl) ?>" target="_blank">Open Resume</a>
                        </div>
                    <?php else: ?>
                        <div class="resume-info">
                            <p>No resume uploaded yet. Upload a PDF and it will be displayed below.</p>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="resume-preview">
                    <?php if ($resumeUrl): ?>
                        <object data="<?= htmlspecialchars($resumeUrl) ?>" type="application/pdf" width="100%" height="600">
                            <p>Your browser does not support embedded PDFs. <a href="<?= htmlspecialchars($resumeUrl) ?>" target="_blank">Download the resume</a>.</p>
                        </object>
                    <?php else: ?>
                        <div class="resume-placeholder">
                            <p>Resume preview will appear here after a successful upload.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <section id="projects" class="section-panel section-alt">
            <div class="container section-header">
                <h2>Projects</h2>
                <p>Highlight your work with clean, modern project cards. Update these entries with your own apps, research, and capstone projects.</p>
            </div>
            <div class="container project-grid">
                <?php foreach ($projects as $project): ?>
                    <article class="project-card">
                        <div class="project-top">
                            <h3><?= htmlspecialchars($project['title']) ?></h3>
                        </div>
                        <p><?= htmlspecialchars($project['description']) ?></p>
                        <div class="project-tags">
                            <?php foreach ($project['tags'] as $tag): ?>
                                <span><?= htmlspecialchars($tag) ?></span>
                            <?php endforeach; ?>
                        </div>
                        <a class="project-link" href="<?= htmlspecialchars($project['link']) ?>" target="_blank">Learn more</a>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section id="contact" class="section-panel">
            <div class="container section-header">
                <h2>Contact</h2>
                <p>Let's connect. Share your GitHub, email, or LinkedIn details and make it easy for recruiters to reach you.</p>
            </div>
            <div class="container contact-grid">
                <div class="contact-card">
                    <h3>GitHub</h3>
                    <p>Keep your repository link visible so visitors can explore your code and contributions.</p>
                    <a class="button button-secondary" href="<?= htmlspecialchars($githubUrl) ?>" target="_blank">Visit GitHub</a>
                </div>
                <div class="contact-card">
                    <h3>Connect</h3>
                    <p>Email: <a href="mailto:your.email@example.com">your.email@example.com</a></p>
                    <p>Location: Remote / Open to opportunities</p>
                </div>
            </div>
        </section>
    </main>

    <footer class="site-footer">
        <div class="container footer-inner">
            <p>Built using HTML, PHP, and JavaScript • Modern blue-accented portfolio design</p>
            <a href="<?= htmlspecialchars($githubUrl) ?>" target="_blank">GitHub</a>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
