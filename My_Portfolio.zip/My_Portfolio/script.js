const fileInput = document.getElementById('resume');
const fileLabel = document.querySelector('.file-input-label');

if (fileInput && fileLabel) {
  fileInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
      fileLabel.textContent = `Selected file: ${file.name}`;
    } else {
      fileLabel.textContent = 'Choose a PDF resume';
    }
  });
}

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (!prefersReducedMotion) {
  document.querySelectorAll('section').forEach((section, index) => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(24px)';
    section.style.transition = 'opacity 0.75s ease, transform 0.75s ease';
    setTimeout(() => {
      section.style.opacity = '1';
      section.style.transform = 'translateY(0)';
    }, 120 * index + 200);
  });
}
